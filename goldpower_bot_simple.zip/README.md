
# GoldPowerSignalsBot (simple)

Готовый минимальный проект Telegram-бота для Render.

## Файлы
- `bot.py` — код бота (использует long polling)
- `requirements.txt` — зависимости

## Как запустить на Render
1. Создайте репозиторий на GitHub (например, `goldpower-bot`).
2. Загрузите туда два файла: `bot.py` и `requirements.txt`.
3. На Render создайте **Background Worker** (а не Web Service).
4. Подключите репозиторий и в настройках укажите:
   - **Start Command**: `python bot.py`
   - **Environment** → **Add Environment Variable**: `TOKEN` = *ваш токен от BotFather*
5. Нажмите **Deploy**. Через минуту бот ответит на команды:
   - `/start`
   - `/signal`

> Если вы уже на шаге Web Service — вернитесь назад и выберите **Background Worker**, так как телеграм-боту не нужен веб-порт при long polling.

Когда будете готовы — подключим сюда автоматическую отправку AI-сигналов по расписанию.
